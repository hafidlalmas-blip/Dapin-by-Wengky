# DAPIN by Wengs — prototipe web app

Prototipe statis, mobile-first, tema hitam dan emas. Fitur:
- Kalkulator simulasi dengan nominal, tenor, asumsi bunga bulanan.
- Perhitungan bunga sederhana dan angsuran rata-rata.
- Tombol berbagi hasil simulasi.
- PWA dasar (manifest + service worker) untuk hosting melalui HTTPS.
- Tidak mengumpulkan data pengguna, tidak menerima pengajuan dan tidak menyalurkan pinjaman.

## Uji cepat di HP Android
1. Ekstrak ZIP.
2. Buka `index.html` dengan editor kode/preview HTML yang mendukung JavaScript, atau pindahkan folder ke komputer dan jalankan server lokal.
3. Untuk menguji seperti web sungguhan dan fitur PWA, unggah ke hosting HTTPS (petunjuk di bawah).

Membuka `index.html` langsung dari file manager bisa membuat fitur service worker/install tidak tersedia. Kalkulator tetap seharusnya berfungsi pada browser modern.

## Publikasi gratis lewat GitHub Pages
1. Buat akun di https://github.com/ jika belum punya.
2. Buat repository baru, misalnya `dapin-by-wengs`. Pilih Public.
3. Unggah semua file dari folder ini ke root repository: `index.html`, `manifest.webmanifest`, `icon.svg`, dan `sw.js`.
4. Buka repository → Settings → Pages.
5. Pada bagian Build and deployment, pilih Deploy from a branch, branch `main`, folder `/(root)`, lalu Save.
6. Tunggu proses selesai. GitHub akan menampilkan URL publik untuk website kamu. Gunakan URL yang tampil di pengaturan Pages; jangan menebak URL.
7. Buka URL itu di Chrome Android. Dari menu ⋮, pilih “Tambahkan ke layar utama” atau “Install app” jika opsi tersedia.

## Alternatif hosting gratis
Netlify atau Cloudflare Pages juga dapat meng-host website statis. Ikuti petunjuk resmi masing-masing layanan dan unggah folder/file website. Nama menu dan batas paket dapat berubah.

## Catatan penting
- Jangan tambahkan formulir KTP, rekening, kontak, atau pengajuan pinjaman ke prototipe ini.
- Kalkulator memakai bunga sederhana: total = pokok + (pokok × bunga bulanan × tenor). Ini bukan metode semua produk kredit.
- Untuk bisnis pinjaman sungguhan, konsultasikan model usaha dan kewajiban perizinan dengan OJK/penasihat hukum sebelum beroperasi.
- Domain khusus bersifat opsional dan biasanya memerlukan biaya tahunan.
